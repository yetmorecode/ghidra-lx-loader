# ghidra-lx-loader

Ghidra Loader for the LX/LE executable file format

## Installation

Download a release matching your ghidra version from the [releases](https://github.com/oshogbo/ghidra-lx-loader/releases) to the `Extensions/Ghidra` inside your Ghidra installation and enabled it from `File > Install extensions...`.

## Features

## Resources

